<?php  
// Product Details  
// Minimum amount is $0.50 US  
$productName = "Demo Product";  
$productID = "DP12345";  
$productPrice = 25; 
$currency = "usd"; 
 
// Convert product price to cent 
$stripeAmount = round($productPrice*100, 2); 
  
// Stripe API configuration   
define('STRIPE_API_KEY', 'sk_test_51HRuk5ARaOHTtTjSClsSGr5lMK3SGI3z26fhs5U5Uj59sYkmqI4PqLB8EBJaZ8FffVtWlx0fn92gi7w1EIFV7HXn003HysH6kI');  
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51HRuk5ARaOHTtTjSJaJZu4XB0pXxlDiW167s8MOOAb4qXjbdTZlb2u5M9nlmaVqpYIjQj8OxSF6yUEwkIe2eDZ6U005idAtZeK');  
define('STRIPE_SUCCESS_URL', 'http://knovatek.co/knovatek/ecommerce_grp/paypal/success.php'); 
define('STRIPE_CANCEL_URL', 'http://knovatek.co/knovatek/ecommerce_grp/paypal/cancel.php'); 
   
// Database configuration   
define('DB_HOST', 'localhost');  
define('DB_USERNAME', 'root');  
define('DB_PASSWORD', '');  
define('DB_NAME', 'stripe'); 