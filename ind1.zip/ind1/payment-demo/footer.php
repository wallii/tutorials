<div id="footer-wrapper"><div class="section">

          <div id="footer" class="clearfix">
          <div class="region region-footer">
    <div id="block-block-11" class="block block-block">

    
  <div class="content">
    <p>© 2021 Wealth-Come. All rights reserved.</p>
  </div>
</div>
  </div>
      </div> <!-- /#footer -->
    
  </div></div> 

</div></div> 
  </body>
</html>