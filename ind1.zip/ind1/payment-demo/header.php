<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"
  "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" version="XHTML+RDFa 1.0" dir="ltr"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:dc="http://purl.org/dc/terms/"
  xmlns:foaf="http://xmlns.com/foaf/0.1/"
  xmlns:og="http://ogp.me/ns#"
  xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#"
  xmlns:sioc="http://rdfs.org/sioc/ns#"
  xmlns:sioct="http://rdfs.org/sioc/types#"
  xmlns:skos="http://www.w3.org/2004/02/skos/core#"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema#">
<?php 
error_reporting(E_ALL);
define('SITE_URL','https://knovatek.co/knovatek/ecommerce_grp');
define('DRUPAL_ROOT', '/home/csjobpyg/public_html/knovatek.co/knovatek/ecommerce_grp');
//define('DRUPAL_ROOT', getcwd());
//echo DRUPAL_ROOT;
$test= '/home/csjobpyg/public_html/knovatek.co/knovatek/ecommerce_grp/includes/bootstrap.inc';
require_once DRUPAL_ROOT . '/includes/bootstrap.inc';
//require_once '/home/csjobpyg/public_html/knovatek.co/knovatek/ecommerce_grp/includes/bootstrap.inc';
drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);
//menu_execute_active_handler();

global $user;
echo $user->uid;
?>
<head profile="http://www.w3.org/1999/xhtml/vocab">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Generator" content="Drupal 7 (http://drupal.org)" />
<link rel="alternate" type="application/rss+xml" title="Wealth-Come RSS" href="<?php echo SITE_URL; ?>/rss.xml" />
<link rel="shortcut icon" href="<?php echo SITE_URL; ?>/sites/default/files/logo_0.png" type="image/png" />
  <title>Wealth-Come</title>
  <style type="text/css" media="all">
@import url("<?php echo SITE_URL; ?>/modules/system/system.base.css?qmancf");
@import url("<?php echo SITE_URL; ?>/modules/system/system.menus.css?qmancf");
@import url("<?php echo SITE_URL; ?>/modules/system/system.messages.css?qmancf");
@import url("<?php echo SITE_URL; ?>/modules/system/system.theme.css?qmancf");
</style>
<style type="text/css" media="all">
@import url("<?php echo SITE_URL; ?>/sites/all/modules/contrib/views_slideshow/views_slideshow.css?qmancf");
</style>
<style type="text/css" media="all">
@import url("<?php echo SITE_URL; ?>/modules/comment/comment.css?qmancf");
@import url("<?php echo SITE_URL; ?>/sites/all/modules/contrib/date/date_api/date.css?qmancf");
@import url("<?php echo SITE_URL; ?>/sites/all/modules/contrib/date/date_popup/themes/datepicker.1.7.css?qmancf");
@import url("<?php echo SITE_URL; ?>/sites/all/modules/contrib/date/date_repeat_field/date_repeat_field.css?qmancf");
@import url("<?php echo SITE_URL; ?>/modules/field/theme/field.css?qmancf");
@import url("<?php echo SITE_URL; ?>/modules/node/node.css?qmancf");
@import url("<?php echo SITE_URL; ?>/modules/search/search.css?qmancf");
@import url("<?php echo SITE_URL; ?>/modules/user/user.css?qmancf");
@import url("<?php echo SITE_URL; ?>/sites/all/modules/contrib/youtube/css/youtube.css?qmancf");
@import url("<?php echo SITE_URL; ?>/sites/all/modules/contrib/views/css/views.css?qmancf");
</style>
<style type="text/css" media="all">
@import url("<?php echo SITE_URL; ?>/sites/all/modules/contrib/ctools/css/ctools.css?qmancf");
@import url("<?php echo SITE_URL; ?>/sites/all/modules/contrib/video/css/video.css?qmancf");
@import url("<?php echo SITE_URL; ?>/sites/all/modules/contrib/views_slideshow/contrib/views_slideshow_cycle/views_slideshow_cycle.css?qmancf");
</style>
<style type="text/css" media="all">
@import url("<?php echo SITE_URL; ?>/sites/all/themes/wealth/css/layout.css?qmancf");
@import url("<?php echo SITE_URL; ?>/sites/all/themes/wealth/css/style.css?qmancf");
@import url("<?php echo SITE_URL; ?>/sites/all/themes/wealth/css/colors.css?qmancf");
@import url("<?php echo SITE_URL; ?>/sites/all/themes/wealth/css/bootstrap.min.css?qmancf");
</style>
<style type="text/css" media="print">
@import url("<?php echo SITE_URL; ?>/sites/all/themes/wealth/css/print.css?qmancf");
</style>

<!--[if lte IE 7]>
<link type="text/css" rel="stylesheet" href="<?php echo SITE_URL; ?>/sites/all/themes/wealth/css/ie.css?qmancf" media="all" />
<![endif]-->

<!--[if IE 6]>
<link type="text/css" rel="stylesheet" href="<?php echo SITE_URL; ?>/sites/all/themes/wealth/css/ie6.css?qmancf" media="all" />
<![endif]-->
  <script type="text/javascript" src="<?php echo SITE_URL; ?>/sites/all/modules/contrib/jquery_update/replace/jquery/1.9/jquery.js?v=1.9.1"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>/misc/jquery-extend-3.4.0.js?v=1.9.1"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>/misc/jquery-html-prefilter-3.5.0-backport.js?v=1.9.1"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>/misc/jquery.once.js?v=1.2"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>/misc/drupal.js?qmancf"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>/sites/all/modules/contrib/views_slideshow/js/views_slideshow.js?v=1.0"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>/sites/all/modules/contrib/admin_menu/admin_devel/admin_devel.js?qmancf"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>/sites/all/modules/contrib/video/js/video.js?qmancf"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>/sites/all/libraries/jquery.cycle/jquery.cycle.all.js?qmancf"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>/sites/all/modules/contrib/views_slideshow/contrib/views_slideshow_cycle/js/views_slideshow_cycle.js?qmancf"></script>
<script type="text/javascript" src="<?php echo SITE_URL; ?>/sites/all/themes/wealth/js/bootstrap.min.js?qmancf"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/knovatek\/ecommerce_grp\/","pathPrefix":"","ajaxPageState":{"theme":"wealth","theme_token":"6hONOt42PPnMcpgKruVAUcLhl4Z4lqjdyO9vZ-H4AsY","js":{"sites\/all\/modules\/contrib\/jquery_update\/replace\/jquery\/1.9\/jquery.js":1,"misc\/jquery-extend-3.4.0.js":1,"misc\/jquery-html-prefilter-3.5.0-backport.js":1,"misc\/jquery.once.js":1,"misc\/drupal.js":1,"sites\/all\/modules\/contrib\/views_slideshow\/js\/views_slideshow.js":1,"sites\/all\/modules\/contrib\/admin_menu\/admin_devel\/admin_devel.js":1,"sites\/all\/modules\/contrib\/video\/js\/video.js":1,"sites\/all\/libraries\/jquery.cycle\/jquery.cycle.all.js":1,"sites\/all\/modules\/contrib\/views_slideshow\/contrib\/views_slideshow_cycle\/js\/views_slideshow_cycle.js":1,"sites\/all\/themes\/wealth\/js\/bootstrap.min.js":1},"css":{"modules\/system\/system.base.css":1,"modules\/system\/system.menus.css":1,"modules\/system\/system.messages.css":1,"modules\/system\/system.theme.css":1,"sites\/all\/modules\/contrib\/views_slideshow\/views_slideshow.css":1,"modules\/comment\/comment.css":1,"sites\/all\/modules\/contrib\/date\/date_api\/date.css":1,"sites\/all\/modules\/contrib\/date\/date_popup\/themes\/datepicker.1.7.css":1,"sites\/all\/modules\/contrib\/date\/date_repeat_field\/date_repeat_field.css":1,"modules\/field\/theme\/field.css":1,"modules\/node\/node.css":1,"modules\/search\/search.css":1,"modules\/user\/user.css":1,"sites\/all\/modules\/contrib\/youtube\/css\/youtube.css":1,"sites\/all\/modules\/contrib\/views\/css\/views.css":1,"sites\/all\/modules\/contrib\/ctools\/css\/ctools.css":1,"sites\/all\/modules\/contrib\/video\/css\/video.css":1,"sites\/all\/modules\/contrib\/views_slideshow\/contrib\/views_slideshow_cycle\/views_slideshow_cycle.css":1,"sites\/all\/themes\/wealth\/css\/layout.css":1,"sites\/all\/themes\/wealth\/css\/style.css":1,"sites\/all\/themes\/wealth\/css\/colors.css":1,"sites\/all\/themes\/wealth\/css\/bootstrap.min.css":1,"sites\/all\/themes\/wealth\/css\/print.css":1,"sites\/all\/themes\/wealth\/css\/ie.css":1,"sites\/all\/themes\/wealth\/css\/ie6.css":1}},"viewsSlideshow":{"slider-block_1":{"methods":{"goToSlide":["viewsSlideshowPager","viewsSlideshowSlideCounter","viewsSlideshowCycle"],"nextSlide":["viewsSlideshowPager","viewsSlideshowSlideCounter","viewsSlideshowCycle"],"pause":["viewsSlideshowControls","viewsSlideshowCycle"],"play":["viewsSlideshowControls","viewsSlideshowCycle"],"previousSlide":["viewsSlideshowPager","viewsSlideshowSlideCounter","viewsSlideshowCycle"],"transitionBegin":["viewsSlideshowPager","viewsSlideshowSlideCounter"],"transitionEnd":[]},"paused":0}},"viewsSlideshowCycle":{"#views_slideshow_cycle_main_slider-block_1":{"num_divs":1,"id_prefix":"#views_slideshow_cycle_main_","div_prefix":"#views_slideshow_cycle_div_","vss_id":"slider-block_1","effect":"fade","transition_advanced":0,"timeout":5000,"speed":700,"delay":0,"sync":1,"random":0,"pause":1,"pause_on_click":0,"play_on_hover":0,"action_advanced":0,"start_paused":0,"remember_slide":0,"remember_slide_days":1,"pause_in_middle":0,"pause_when_hidden":0,"pause_when_hidden_type":"full","amount_allowed_visible":"","nowrap":0,"pause_after_slideshow":0,"fixed_height":1,"items_per_slide":1,"wait_for_image_load":1,"wait_for_image_load_timeout":3000,"cleartype":0,"cleartypenobg":0,"advanced_options":"{}"}}});
//--><!]]>
</script>
</head>
<body class="html front not-logged-in no-sidebars page-node" >
  <div id="skip-link">
    <a href="#main-content" class="element-invisible element-focusable">Skip to main content</a>
  </div>
    
<div id="page-wrapper"><div id="page">
<section class="main-header">
<div class="container">
	<div class="row">
		<div class="col-md-5">      <a href="/knovatek/ecommerce_grp/" title="Wealth Come" rel="home" id="logo">
        <img src="<?php echo SITE_URL; ?>/sites/default/files/logo.png" alt="Wealth Come" class="imglogo" />
      </a>
    	 <div id="site-name">
              <strong>
                <a href="/knovatek/ecommerce_grp/" title="Home" rel="home"><span>Wealth-Come</span></a>
              </strong>
            </div>
	
	
	</div>
		<div class="col-md-7">
		
		       <div id="main-menu" class="navigation">
        <h2 class="element-invisible">Main menu</h2><ul id="main-menu-links" class="links clearfix"><li class="menu-219 first active"><a href="/knovatek/ecommerce_grp/" class="active">Home</a></li>
<li class="menu-303"><a href="/knovatek/ecommerce_grp/about-us">About Us</a></li>
<li class="menu-304"><a href="/knovatek/ecommerce_grp/how-it-works">How it Works</a></li>
<li class="menu-305"><a href="/knovatek/ecommerce_grp/user/login" title="">Login</a></li>
<li class="menu-306 last"><a href="/knovatek/ecommerce_grp/user/register" title="">Register</a></li>
</ul>      </div> <!-- /#main-menu -->
    		
		
		</div>
	</div>
</div>
</section>

  <div id="header" class="without-secondary-menu"><div class="section clearfix">


  </div></div> <!-- /.section, /#header -->