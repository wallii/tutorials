<?php
/**
 * @file msnf-block-step-info.tpl.php
 *
 * Displays information about the current form step as block content.
 *
 * Available variables:
 * - $steps_rendered
 *   Step titles rendered as simple item list.
 */
?>
<?php
print $steps_rendered;
