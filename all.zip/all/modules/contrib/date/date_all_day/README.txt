Date All Day

This module provides the option to add an 'All Day' checkbox to toggle time on 
and off for date fields. It also contains the theme that displays the 'All Day' 
text on fields that have no time. 

Additionally, this module serves as an example of how other modules can inject 
new functionality into date fields using various hooks provided by Date and by 
the Field API.