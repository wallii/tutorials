<div class="cshs-term-group">
  <div class="cshs-term-group__title">
    <?php print $title; ?>
  </div>
  <div class="cshs-term-group__terms">
    <?php foreach($terms as $term): ?>
      <div class="cshs-term-group__term"><?php print $term; ?></div>
    <?php endforeach; ?>
  </div>
</div>