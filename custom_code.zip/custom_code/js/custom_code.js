jQuery(document).ready(function(){
	
	 //alert(123);
	
	jQuery("#edit-field-quantity-und-0-value" ).attr("type","number");
	//alert('done')
    jQuery("#edit-field-year-purchased-und-0-value" ).attr("type","number");
	jQuery("#edit-field-year-purchased-und-0-value" ).attr("type","number");
	jQuery("#edit-field-year-purchased-und-0-value" ).attr("placeholder","2002");
	jQuery("#edit-field-tax-und-0-value" ).attr("type","number");
	
	jQuery("#edit-field-year-purchased-und-0-value").focusout(function(){
        var purcye = jQuery("#edit-field-year-purchased-und-0-value").val();
	    var d = new Date();
        var n = d.getFullYear();
		var fg = n - purcye;
		jQuery("#edit-field-age-und-0-value").val(fg);
    });
	
	
	 // jQuery("#edit-field-age-und-0-value").val(n);
	  //alert(n);
	

});